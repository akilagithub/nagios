<?php

include(dirname(__FILE__).'response.php');

?>